class Product:
    def __init__(self, product_id, name, price, quantity):
        self.product_id = product_id
        self.name = name
        self.price = price
        self.quantity = quantity

    def __str__(self):
        return f"{self.name} - ${self.price} ({self.quantity} in stock)"

class Cart:
    def __init__(self):
        self.items = {}

    def add_to_cart(self, product, quantity):
        if product.product_id in self.items:
            self.items[product.product_id]['quantity'] += quantity
        else:
            self.items[product.product_id] = {'product': product, 'quantity': quantity}

    def view_cart(self):
        total_price = 0
        for item in self.items.values():
            product = item['product']
            quantity = item['quantity']
            total_price += product.price * quantity
            print(f"{product.name} - ${product.price} x {quantity}")

        print(f"Total Price: ${total_price}")

class Supermarket:
    def __init__(self):
        self.products = {}

    def add_product(self, product):
        self.products[product.product_id] = product

    def display_products(self):
        print("Available Products:")
        for product in self.products.values():
            print(product)

def main():
    supermarket = Supermarket()
    cart = Cart()

    # Adding some initial products
    product1 = Product(1, "Apples", 2.0, 50)
    product2 = Product(2, "Bananas", 1.5, 100)
    product3 = Product(3, "Milk", 3.0, 30)

    supermarket.add_product(product1)
    supermarket.add_product(product2)
    supermarket.add_product(product3)

    while True:
        print("\nOptions:")
        print("1. Display Products")
        print("2. Add to Cart")
        print("3. View Cart")
        print("4. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            supermarket.display_products()
        elif choice == '2':
            product_id = int(input("Enter the product ID: "))
            quantity = int(input("Enter the quantity: "))
            if product_id in supermarket.products:
                product = supermarket.products[product_id]
                cart.add_to_cart(product, quantity)
            else:
                print("Product not found.")
        elif choice == '3':
            cart.view_cart()
        elif choice == '4':
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
